export const environment = {
    production: false,
    api: {
        schedulerService: {
            root: "http://localhost:8080/api",
            auth: {
                login: "/auth/login",
                register: "/auth/register"
            },
            user: {
                current: `/user`
            },
            goal: {
                all: '/goal',
                delete: (goalId: number) => `/goal/${goalId}`,
                tasks: (goalId: number) => `/goal/${goalId}/tasks`
            },
            task: {
                create: (goalId: number) => `/goal/${goalId}`,
                delete: (goalId: number, taskId: number) => `/goal/${goalId}/task/${taskId}`
            }
        }
    }
};