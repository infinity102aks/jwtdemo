import { Injectable, inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { IAuthResponse, IUser } from '../models/auth-interface';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {
 
  constructor(private router: Router) { }

  public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const authCookie = localStorage.getItem("Bearer");

    if (!authCookie) {
      this.router.navigate(['/auth']);
      return false;
    }

    return true;
  }

  public static isLoggedIn(): boolean {
    return !!localStorage.getItem("Bearer");
  }

  public static saveAuth(auth: IAuthResponse): void {
    localStorage.setItem(auth.tokenType, auth.token);
  }

  public static logout(): void {
    localStorage.removeItem("Bearer");
    localStorage.removeItem("user");
  }

  public static saveCurrentUser(user: IUser): void {
    localStorage.setItem('user', JSON.stringify(user));
  }

  public static currentUser(): IUser {
    return JSON.parse(localStorage.getItem('user') || '');
  }
}


export const authGuard: CanActivateFn = (route, state) => {
  return inject(AuthGuardService).canActivate(route, state);
};

