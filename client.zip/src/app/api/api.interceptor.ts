import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { AuthGuardService } from '../guards/auth.guard';
import { Router } from '@angular/router';

@Injectable()
export class ApiInterceptor implements HttpInterceptor {

  constructor(private readonly router: Router) { }

  public intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (!AuthGuardService.isLoggedIn() && !this.router.url.includes("/auth")) {
      this.router.navigate(['/auth']);
    }

    return next.handle(request).pipe(
      tap({
        error: (error: HttpErrorResponse) => {
          if (error.status === 401) {
            AuthGuardService.logout();
            this.router.navigate(['/auth']);
          }
        }
      }));
  }
}
