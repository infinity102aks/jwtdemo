import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseAPIService {

  private readonly schedulerServiceAPI = environment.api.schedulerService;

  constructor(private readonly http: HttpClient) {}

  public get(path: string): Observable<any> {
    return this.http.get(this.url(path), {withCredentials: true});
  }

  public post(path: string, payload: unknown): Observable<any> {
    return this.http.post(this.url(path), payload, { withCredentials: true });
  }

  public put(path: string, payload: unknown): Observable<any> {
    return this.http.put(this.url(path), payload, { withCredentials: true });
  }

  public delete(path: string): Observable<any> {
    return this.http.delete(this.url(path), { withCredentials: true });
  }

  private url(path: string): string {
    return this.schedulerServiceAPI.root+path;
  }
}
