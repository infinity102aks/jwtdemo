import { TimeRangePipe } from './time-range.pipe';

describe('TimeRangePipe', () => {
  it('create an instance', () => {
    const pipe = new TimeRangePipe();
    expect(pipe).toBeTruthy();
  });
});
