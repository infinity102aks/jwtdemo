import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TimeRangePipe } from './time-range.pipe';



@NgModule({
  declarations: [
    TimeRangePipe
  ],
  imports: [
    CommonModule
  ],
  exports: [
    TimeRangePipe
  ]
})
export class PipesModule { }
