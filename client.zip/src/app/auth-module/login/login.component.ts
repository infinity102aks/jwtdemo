import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BaseAPIService } from 'src/app/api/base.service';
import { AuthGuardService } from 'src/app/guards/auth.guard';
import { IAuthResponse } from 'src/app/models/auth-interface';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  public loginForm: FormGroup | undefined;
  private loginAPI: string = environment.api.schedulerService.auth.login;
  private subscription = new Subscription();

  constructor(private readonly router: Router, private readonly baseApi: BaseAPIService, private readonly formBuilder: FormBuilder) {}
  
  public ngOnInit(): void {
    this.createLoginForm();
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public onLogin(): void {
    if (!this.loginForm?.valid) {
      this.loginForm?.markAllAsTouched();
      return;
    }

    this.loginForm.setErrors(null);
    this.tryToLogin();

  }

  private tryToLogin(): void {
    const sub = this.baseApi.post(this.loginAPI, this.loginForm?.value).subscribe({
      next: (response: IAuthResponse) => {
        AuthGuardService.saveAuth(response);
        this.router.navigate(['/home']);
      }
    });
    this.subscription.add(sub);
  }


  private createLoginForm(): void {
    this.loginForm = this.formBuilder.group({
      email: [null, Validators.required],
      password: [null, Validators.required]
    });
  }
}
