import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BaseAPIService } from 'src/app/api/base.service';
import { AuthGuardService } from 'src/app/guards/auth.guard';
import { IAuthResponse, IUser } from 'src/app/models/auth-interface';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, OnDestroy {

  public registrationForm: FormGroup | undefined;
  private registerAPI: string = environment.api.schedulerService.auth.register;
  private subscription = new Subscription();

  constructor(private router: Router, private readonly baseApi: BaseAPIService, private readonly formBuilder: FormBuilder) { }

  public ngOnInit(): void {
    this.createRegisterForm();
  }
  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public onRegister() {
    if (!this.registrationForm?.valid) {
      this.registrationForm?.markAllAsTouched();
      return;
    }

    this.registrationForm.setErrors(null);
    this.tryToRegister();

  }

  private tryToRegister(): void {
    const sub = this.baseApi.post(this.registerAPI, this.registrationForm?.value).subscribe({
      next: (response: IUser) => {
        this.router.navigate(['/auth/login']);
      }
    });
    this.subscription.add(sub);
  }


  private createRegisterForm(): void {
    this.registrationForm = this.formBuilder.group({
      email: [null, Validators.required],
      password: [null, Validators.required],
      name: [null, Validators.required]
    })
  }
}
