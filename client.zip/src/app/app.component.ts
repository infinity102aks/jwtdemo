import { Component, OnInit } from '@angular/core';
import { AuthGuardService } from './guards/auth.guard';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'schedulerClient';

  constructor(private readonly router: Router){}

  public ngOnInit(): void {
    this.redirectIfLoginNotRequired();
  }

  private redirectIfLoginNotRequired() {
    if (AuthGuardService.isLoggedIn()) {
      this.router.navigate(['home']);
    }
  }
}
