import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatISO } from 'date-fns';
import { format, getTimezoneOffset } from 'date-fns-tz';
import { Subscription } from 'rxjs';
import { BaseAPIService } from 'src/app/api/base.service';
import { IGoal, ITask } from 'src/app/models/home-models.interface';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-goal',
  templateUrl: './goal.component.html',
  styleUrls: ['./goal.component.scss']
})
export class GoalComponent implements OnInit, OnDestroy {

  public goals: IGoal[] = [];
  public tasks: ITask[] = [];
  public goalForm?: FormGroup | any;
  public isNewGoal = false;
  public activeGoal: IGoal | undefined;
  public activeGoalIndex: number = -1;
  private subscription: Subscription = new Subscription();

  public constructor(private readonly baseAPI: BaseAPIService, private readonly formBuilder: FormBuilder) { }

  public ngOnInit(): void {
    this.getAllGoals();
  }
  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public selectGoal(goal: IGoal, goalIndex: number) {
    this.activeGoal = goal;
    this.activeGoalIndex = goalIndex;
    this.loadGoalTasks(goal.id);
  }

  public saveGoal(): void {
    const goalFormValue: IGoal = this.goalForm.value;
    goalFormValue.expiry = formatISO(goalFormValue.expiry);
    const req = this.isNewGoal ?
      this.baseAPI.post(environment.api.schedulerService.goal.all, goalFormValue) :
      this.baseAPI.put(environment.api.schedulerService.goal.all, goalFormValue)
    const sub = req.subscribe({
      next: (response: IGoal) => {
        if (this.isNewGoal) {
          this.goals.push(response);
        } else {
          this.goals[this.activeGoalIndex] = response;
        }
      }
    });
    this.subscription.add(sub);
    this.goalForm = null;
  }

  public createGoalForm(goal?: IGoal): void {
    this.isNewGoal = !goal;
    let date: string = '';
    if (!this.isNewGoal) {
      date = format(goal?.expiry || '', 'yyyy-MM-dd');
    }
    this.goalForm = this.formBuilder.group({
      id: [goal?.id || null],
      name: [goal?.name || null, Validators.required],
      expiry: [date, Validators.required]
    });
  }

  public deleteGoal(i: number): void {
    let confirmation = confirm("Are you sure");
    if (confirmation) {
      const sub = this.baseAPI.delete(environment.api.schedulerService.goal.delete(this.goals[i].id)).subscribe({
        next: () => {
          this.goals.splice(i, 1);
          if (this.activeGoalIndex === i) {
            this.activeGoalIndex = i < this.goals.length-1 ? this.activeGoalIndex + 1 : 0;
            this.activeGoal = this.goals[this.activeGoalIndex];
            this.loadGoalTasks(this.activeGoal.id);
          }
        }
      });
      this.subscription.add(sub);
    }
  }

  public createNewTask(task: ITask): void {
    if (!this.activeGoal) {
      return;
    }

    const sub = this.baseAPI.post(environment.api.schedulerService.task.create(this.activeGoal?.id ), [task]).subscribe({
      next: (response: ITask[]) => {
        this.tasks.push(...response);
      }
    });
    
    this.subscription.add(sub);
  }

  public updateTask(task: ITask, index: number): void {
    if (!this.activeGoal) {
      return;
    }

    const sub = this.baseAPI.put(environment.api.schedulerService.task.create(this.activeGoal?.id), task).subscribe({
      next: (response: ITask) => {
        this.tasks[index] = response;
      }
    });

    this.subscription.add(sub);
  }

  public deleteTask(index: number): void {
    if (!this.activeGoal) {
      return;
    }

    const confirmation = confirm("Are you sure?");
    if (!confirmation) {
      return;
    }

    const sub = this.baseAPI.delete(environment.api.schedulerService.task.delete(this.activeGoal?.id, this.tasks[index].id)).subscribe({
      next: (response: ITask) => {
        this.tasks.splice(index, 1);
      }
    });

    this.subscription.add(sub);
  }

  private getAllGoals(): void {
    const sub = this.baseAPI.get(environment.api.schedulerService.goal.all).subscribe({
      next: (goals: IGoal[]) => {
        if (goals.length) {
          this.goals = goals;
          this.selectGoal(goals[0], 0);
        }
      }
    });
    this.subscription.add(sub);
  }

  private loadGoalTasks(goalId: number) {
    const sub = this.baseAPI.get(environment.api.schedulerService.goal.tasks(goalId)).subscribe({
      next: (tasks: ITask[]) => {
        this.tasks = tasks;
      }
    });
    this.subscription.add(sub);
  }
}
