import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuardService } from '../guards/auth.guard';
import { Subscription } from 'rxjs';
import { IUser } from '../models/auth-interface';
import { BaseAPIService } from '../api/base.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy{

  public currentUser: IUser | undefined;
  private subscription: Subscription = new Subscription();

  public constructor(private readonly router: Router, private readonly baseApi: BaseAPIService) {}
  
  public ngOnInit(): void {
    this.loadUserData();
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public loadUserData(): void {
    const sub = this.baseApi.get(environment.api.schedulerService.user.current).subscribe({
      next: (response: IUser) => {
        AuthGuardService.saveCurrentUser(response);
        this.currentUser = response;
      }
    });

    this.subscription.add(sub);
  }

  public logout(): void {
    AuthGuardService.logout();
    this.router.navigate(['/auth']);
  }
}
