import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IUser } from 'src/app/models/auth-interface';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  @Input() 
  public user: IUser | undefined;

  @Output()
  public logout: EventEmitter<any> = new EventEmitter();


}
