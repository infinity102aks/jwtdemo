import { Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ITask } from 'src/app/models/home-models.interface';
import { TaskFrequency, TaskFrequencyName, WeekDays } from 'src/app/models/home.enum';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnDestroy{

  @Input()
  public task: ITask | undefined;
  @Output()
  public createTask: EventEmitter<ITask> = new EventEmitter();
  @Output()
  public updateTask: EventEmitter<ITask> = new EventEmitter();
  @Output()
  public deleteTask: EventEmitter<any> = new EventEmitter();

  public taskFrequencies = TaskFrequency;
  public taskFrequencyNames = TaskFrequencyName;
  public weekDays = WeekDays;
  public taskForm?: FormGroup | any;
  public isNewTask = false;

  private subscription: Subscription = new Subscription();

  public constructor(private readonly formBuilder: FormBuilder) { }


  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public get taskFrequencyList(): string[] {
    return Object.keys(this.taskFrequencies);
  }

  public get taskWeekDaysList(): string[] {
    return Object.keys(this.weekDays);
  }

  public createTaskForm(task?: ITask): void {
    this.isNewTask = !task;
    let time1: string;
    let time2: string | any; 
    if (task?.frequency === TaskFrequency.TWICE_A_DAY) {
      [time1, time2] = task?.preferredTime;
    } else {
      time1 = task?.preferredTime as string;
    }
    
    this.taskForm = this.formBuilder.group({
      id: [task?.id || null],
      name: [task?.name || null, Validators.required],
      quantity: [task?.quantity || 1, Validators.required],
      frequency: [task?.frequency, Validators.required],
      remindBefore: [task?.remindBefore || 30, Validators.required],
      description: [task?.description || null],
      preferredTime: [time1, Validators.required],
      secondaryTime: [time2],
      weekDays: [task?.weekDays || []],
      frequencyValue: [task?.frequencyValue || null]
    });

    const sub = this.taskForm.get('frequency')?.valueChanges.subscribe({
      next: (frequency: TaskFrequency) => {
        if (frequency === TaskFrequency.DAYS_OF_WEEK || frequency === TaskFrequency.ONCE_A_WEEK) {
          this.taskForm?.get('weekDays')?.addValidators([Validators.required]);
          this.taskForm?.get('frequencyValue')?.removeValidators([Validators.required]);
          this.taskForm?.get('secondaryTime')?.removeValidators([Validators.required]);
        } else if (frequency === TaskFrequency.NO_OF_DAYS) {
          this.taskForm?.get('weekDays')?.removeValidators([Validators.required]);
          this.taskForm?.get('secondaryTime')?.removeValidators([Validators.required]);
          this.taskForm?.get('frequencyValue')?.addValidators([Validators.required]);
        } else if (frequency === TaskFrequency.TWICE_A_DAY) {
          this.taskForm?.get('weekDays')?.removeValidators([Validators.required]);
          this.taskForm?.get('secondaryTime')?.addValidators([Validators.required]);
          this.taskForm?.get('frequencyValue')?.removeValidators([Validators.required]);
        }
        this.taskForm.updateValueAndValidity();
      }
    });
    this.subscription.add(sub);
  }

  public saveTask(): void {
    if (this.taskForm.invalid) {
      this.taskForm.markAllAsTouched();
      return;
    }

    const formValue = this.taskForm.value;
    if (formValue.frequency === TaskFrequency.TWICE_A_DAY) {
      formValue.preferredTime = [formValue.preferredTime, formValue.secondaryTime].join(",");
      delete formValue.secondaryTime;
    } else if (formValue.frequency === TaskFrequency.ONCE_A_WEEK) {
      formValue.weekDays = [formValue.weekDays]
    }

    if (this.isNewTask){
      this.createTask.emit(formValue);
    } else {
      this.updateTask.emit(formValue);
    }

    this.taskForm = null;
  }
}
