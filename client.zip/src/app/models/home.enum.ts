export enum TaskFrequency {
    ONCE_A_DAY = 'ONCE_A_DAY',
    TWICE_A_DAY = 'TWICE_A_DAY',
    ONCE_A_WEEK = 'ONCE_A_WEEK',
    NO_OF_DAYS = 'NO_OF_DAYS',
    DAYS_OF_WEEK = 'DAYS_OF_WEEK'
}

export enum TaskFrequencyName {
    ONCE_A_DAY = 'Once in a day',
    TWICE_A_DAY = 'Twice in a day',
    ONCE_A_WEEK = 'once in a week',
    NO_OF_DAYS = 'Multiple Days',
    DAYS_OF_WEEK = 'Multiple days of week'
}

export enum WeekDays {
    MONDAY = 'MONDAY', 
    TUESDAY = 'TUESDAY',
    WEDNESDAY = 'WEDNESDAY',
    THURSDAY = 'THURSDAY',
    FRIDAY = 'FRIDAY',
    SATURDAY = 'SATURDAY',
    SUNDAY = 'SUNDAY'
}