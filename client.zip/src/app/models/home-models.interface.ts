import { TaskFrequency, WeekDays } from "./home.enum"

export interface IGoal {
    id: number,
    name: string, 
    expiry: string
}

export interface ITask {
    id: number,
    name: string,
    quantity: number,
    frequency: TaskFrequency
    remindBefore: number,
    description: string,
    preferredTime: string,
    weekDays: WeekDays[],
    frequencyValue: number
}