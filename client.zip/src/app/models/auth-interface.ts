export interface IAuthResponse {
    token: string;
    tokenType: string;
}

export interface IUser {
    id: number,
    name: string,
    email: string,
    role: string
}